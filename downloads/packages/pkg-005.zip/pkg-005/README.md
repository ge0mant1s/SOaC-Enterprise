# SOaC Package: SEO Poisoning & Gootloader Defense (pkg-005)

Detect and contain SEO poisoning campaigns and Gootloader malware delivery
via compromised websites.

## MITRE ATT&CK
- T1189 — Drive-by Compromise
- T1059.007 — Command and Scripting Interpreter: JavaScript
- T1071.001 — Application Layer Protocol: Web Protocols

## License
Apache 2.0 — https://github.com/ge0mant1s/SOaC-Enterprise/blob/main/LICENSE
