# SOaC Package: Ransomware Containment & Response (pkg-002)

Automated host isolation, process killing, forensic snapshot capture,
and SOC notification for ransomware events.

## Contents
- `isolate_host.yaml` — CLAW Playbook for host isolation & containment
- `edge_api_spec_v1.md` — Edge Enforcement API specification

## MITRE ATT&CK
- T1486 — Data Encrypted for Impact
- T1059 — Command and Scripting Interpreter
- T1068 — Exploitation for Privilege Escalation
- T1490 — Inhibit System Recovery

## License
Apache 2.0 — https://github.com/ge0mant1s/SOaC-Enterprise/blob/main/LICENSE
