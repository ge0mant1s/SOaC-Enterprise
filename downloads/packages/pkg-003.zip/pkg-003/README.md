# SOaC Package: Supply Chain & npm Compromise (pkg-003)

Detect and respond to malicious npm packages, dependency confusion,
and software supply chain attacks.

## Contents
- `lab_safety_policy.yaml` — Lab safety policy for supply chain simulation
- `README.md` — This file

## MITRE ATT&CK
- T1195.002 — Supply Chain Compromise: Compromise Software Supply Chain
- T1059.007 — Command and Scripting Interpreter: JavaScript
- T1027 — Obfuscated Files or Information

## License
Apache 2.0 — https://github.com/ge0mant1s/SOaC-Enterprise/blob/main/LICENSE
