# SOaC Package: BYOVD & Kernel Exploit Defense (pkg-004)

Detect Bring Your Own Vulnerable Driver attacks and kernel-level exploitation
used by advanced ransomware operators.

## MITRE ATT&CK
- T1068 — Exploitation for Privilege Escalation
- T1014 — Rootkit
- T1547.006 — Boot or Logon Autostart Execution: Kernel Modules and Extensions

## License
Apache 2.0 — https://github.com/ge0mant1s/SOaC-Enterprise/blob/main/LICENSE
